#include "ui_manager.h"
#include "viewmodels.h"
#include <cstdio>
#include "esp_log.h"
#include "fonts/lv_font_7seg_64.c"
#include "config.h"
#include <driver/gpio.h>

// --- Constructor ---
UIManager::UIManager(ToolManager& tm, DroAxis& x, DroAxis& z, PreferencesWrapper& p)
    : toolManager(tm), xAxis(x), zAxis(z), prefs(p)
{}

// --- Helper Methods ---
struct LabelArgs {
    const lv_font_t* font = LV_FONT_DEFAULT;
    lv_align_t align = LV_ALIGN_TOP_LEFT;
    lv_color_t color = lv_color_white();
    bool clickable = false;
    lv_event_cb_t event_cb; 
    lv_event_code_t filter;
    void *user_data;
};
lv_obj_t *createLabel(const char *text, int32_t x_ofs, int32_t y_ofs, const LabelArgs& args = {}) {
    lv_obj_t *label = lv_label_create(lv_scr_act());
    lv_label_set_text(label, text);
    lv_obj_set_style_text_font(label, args.font, LV_PART_MAIN);
    lv_obj_set_style_text_color(label, args.color, LV_PART_MAIN);
    if(args.clickable) {
        lv_obj_add_flag(label, LV_OBJ_FLAG_CLICKABLE);
    }
    lv_obj_align(label, args.align, x_ofs, y_ofs);
    if(args.event_cb != NULL) lv_obj_add_event_cb(label, args.event_cb, args.filter, args.user_data);
    return label;
};

lv_obj_t *createButton(const char *text, int32_t x_size, int32_t y_size, int32_t x_ofs, int32_t y_ofs, const LabelArgs& args = {}) {
    lv_obj_t *button = lv_btn_create(lv_scr_act());
    lv_obj_set_size(button, x_size, y_size);
    lv_obj_align(button, args.align, x_ofs, y_ofs);
    lv_obj_set_style_bg_color(button, lv_color_make(0x20, 0x20, 0x20), LV_PART_MAIN);
    lv_obj_t* buttonLabel = lv_label_create(button);
    lv_label_set_text(buttonLabel, text);
    lv_obj_center(buttonLabel);
    if(args.event_cb != NULL) lv_obj_add_event_cb(button, args.event_cb, args.filter, args.user_data);
    return button;
};

lv_obj_t *createDropdown(int32_t width, int32_t x_ofs, int32_t y_ofs, const LabelArgs& args = {}) {
    lv_obj_t *dropdown = lv_dropdown_create(lv_scr_act());
    lv_obj_set_width(dropdown, width);
    lv_obj_align(dropdown, args.align, x_ofs, y_ofs);
    if(args.event_cb != NULL) lv_obj_add_event_cb(dropdown, args.event_cb, args.filter, args.user_data);
    return dropdown;
};
lv_obj_t *createPanel(lv_obj_t *parent, int32_t x_ofs, int32_t y_ofs, int32_t width, int32_t height, const LabelArgs& args = {}) {
    lv_obj_t *panel = lv_obj_create(parent);
    lv_obj_set_size(panel, width, height);
    lv_obj_align(panel, args.align, x_ofs, y_ofs);
    lv_obj_set_style_bg_color(panel, args.color, LV_PART_MAIN);
    if(args.event_cb != NULL) lv_obj_add_event_cb(panel, args.event_cb, args.filter, args.user_data);
    return panel;
};
// --- UI Initialization ---
void UIManager::init() {
    lv_obj_clean(lv_scr_act());

    // Create UI Elements
    static int widgets_x = LCD_H_RES*4/7;
    static int widgets_pad = 30;
    static int padding = 8;
    static lv_color_t color_green     = lv_color_make(0x39, 0xff, 0x14);
    static lv_color_t color_dark_grey = lv_color_make(0x08, 0x08, 0x08);
    static lv_color_t color_black     = lv_color_make(0x00, 0x00, 0x00);

    lv_obj_t *leftPanel = createPanel(lv_scr_act(), padding, padding, LCD_H_RES*4/7 - padding * 2, LCD_V_RES - padding*2, {.color = color_black});

    labelX = createLabel("X", 30, 50, {.color = color_green});
    labelZ = createLabel("Z", 30, 150, {.color = color_green});
    createLabel("88888.8888", -LCD_H_RES + widgets_x - 120, 50,  {.font = &lv_font_7seg_64, .align = LV_ALIGN_TOP_RIGHT, .color = color_dark_grey});
    createLabel("88888.8888", -LCD_H_RES + widgets_x - 120, 150, {.font = &lv_font_7seg_64, .align = LV_ALIGN_TOP_RIGHT, .color = color_dark_grey});

    droX = createLabel("0.0000", -LCD_H_RES + widgets_x - 120, 50,  {
            .font = &lv_font_7seg_64, .align = LV_ALIGN_TOP_RIGHT, .color = color_green, 
            .clickable = true,
            .event_cb = &UIManager::droXInputEvent, .filter = LV_EVENT_CLICKED,.user_data = this,
        });
    droZ = createLabel("0.0000", -LCD_H_RES + widgets_x - 120, 150, {
            .font = &lv_font_7seg_64, .align = LV_ALIGN_TOP_RIGHT, .color = color_green, 
            .clickable = true,
            .event_cb = &UIManager::droZInputEvent, .filter = LV_EVENT_CLICKED,.user_data = this,
        });

    btnZeroX =    createButton("Zero", 60, 30, widgets_x - 90, 50 +8, {.event_cb = &UIManager::zeroXEvent, .filter = LV_EVENT_CLICKED,.user_data = this});
    btnZeroZ =    createButton("Zero", 60, 30, widgets_x - 90, 150+8, {.event_cb = &UIManager::zeroZEvent, .filter = LV_EVENT_CLICKED,.user_data = this});
    btnUnit =     createButton("init", 60, 60, widgets_x + widgets_pad, widgets_pad, {.event_cb = &UIManager::unitToggleEvent, .filter = LV_EVENT_CLICKED,.user_data = this});
    btnDiameter = createButton("init", 60, 60, widgets_x + widgets_pad + 90, widgets_pad, {.event_cb = &UIManager::diameterToggleEvent, .filter = LV_EVENT_CLICKED,.user_data = this});

    static int toolWidgetY = widgets_pad*2 + 60;
    toolDropdown =  createDropdown(120, widgets_x + widgets_pad, toolWidgetY, {.event_cb = &UIManager::toolDropdownEvent, .filter = LV_EVENT_VALUE_CHANGED,.user_data = this});
    btnToolEdit =   createButton(LV_SYMBOL_EDIT,    40, 40, widgets_x + widgets_pad + widgets_pad/4 + 120,            toolWidgetY, {.event_cb = &UIManager::toolEditEvent, .filter = LV_EVENT_CLICKED,.user_data = this});
    btnToolRemove = createButton(LV_SYMBOL_TRASH,   40, 40, widgets_x + widgets_pad + widgets_pad*2/4 + 120 + 40,     toolWidgetY, {.event_cb = &UIManager::toolRemoveEvent, .filter = LV_EVENT_CLICKED,.user_data = this});
    btnToolAdd =    createButton(LV_SYMBOL_PLUS,    40, 40, widgets_x + widgets_pad + widgets_pad*3/4 + 120 + 40*2,   toolWidgetY, {.event_cb = &UIManager::toolAddEvent, .filter = LV_EVENT_CLICKED,.user_data = this});

    btnScreenSleep = createButton(LV_SYMBOL_POWER, 60, 60, LCD_H_RES - 60 -8, 8, {.event_cb = &UIManager::sleepBtnEvent, .filter = LV_EVENT_CLICKED,.user_data = this});
    
    // Load Initial States
    updateToolDropdown();
    loadOffsetsFromTool(currentToolIndex);
    loadUnitSettings();
    lv_label_set_text(lv_obj_get_child(btnUnit, 0), isMetric ? "mm" : "in");
    lv_label_set_text(lv_obj_get_child(btnDiameter, 0), isDiameterMode ? "DIA" : "RAD");
    updateDisplay();
}

// --- ViewModel-Powered Display Update ---
void UIManager::updateDisplay() {
    // 1. Populate ViewModel
    viewModel.is_metric = isMetric;
    viewModel.is_diameter_mode = isDiameterMode;

    // Axes
    viewModel.x_axis.label = "X";
    viewModel.z_axis.label = "Z";
    viewModel.x_axis.position_um = xAxis.getPositionUm();
    viewModel.z_axis.position_um = zAxis.getPositionUm();

    // Tool info
    const Tool& tool = toolManager.getTool(currentToolIndex);
    viewModel.current_tool = ToolViewModel(tool.name, tool.x_offset, tool.z_offset, currentToolIndex, true);

    // All tools for dropdown
    viewModel.tool_list.clear();
    for (size_t i = 0; i < toolManager.toolCount(); ++i) {
        const Tool& t = toolManager.getTool(i);
        viewModel.tool_list.emplace_back(t.name, t.x_offset, t.z_offset, (int)i, (int)i == currentToolIndex);
    }

    // 2. Compute axis display/formatting using the ViewModel only
    // X axis
    float pos_x = viewModel.x_axis.position_um / 1000.0f;
    float display_x = pos_x - viewModel.current_tool.x_offset;
    if (!viewModel.is_metric) display_x *= 0.0393701f;
    if (viewModel.is_diameter_mode) display_x *= 2;
    viewModel.x_axis.display_value = display_x;
    char buf[32];
    snprintf(buf, sizeof(buf), "%.4f", display_x);
    viewModel.x_axis.formatted_text = buf;
    lv_label_set_text(droX, viewModel.x_axis.formatted_text.c_str());

    // Z axis
    float pos_z = viewModel.z_axis.position_um / 1000.0f;
    float display_z = pos_z - viewModel.current_tool.z_offset;
    if (!viewModel.is_metric) display_z *= 0.0393701f;
    viewModel.z_axis.display_value = display_z;
    snprintf(buf, sizeof(buf), "%.4f", display_z);
    viewModel.z_axis.formatted_text = buf;
    lv_label_set_text(droZ, viewModel.z_axis.formatted_text.c_str());
}

// -- x & z inputs
void UIManager::droXInputEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->showNumericInputPopup(true); // true = X axis
}

void UIManager::droZInputEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->showNumericInputPopup(false); // false = Z axis
}

// --- Dropdown Update (uses tool names from ViewModel/toolManager) ---
void UIManager::updateToolDropdown() {
    std::string options;
    for (size_t i = 0; i < toolManager.toolCount(); ++i) {
        if (i > 0) options += "\n";
        options += toolManager.getTool(i).name;
    }
    lv_dropdown_set_options(toolDropdown, options.c_str());
    lv_dropdown_set_selected(toolDropdown, currentToolIndex);
}

// --- Tool Offset Loader (after selection/change) ---
void UIManager::loadOffsetsFromTool(int index) {
    if (index >= 0 && static_cast<size_t>(index) < toolManager.toolCount()) {
        currentToolIndex = index;
    }
}

// --- Static LVGL Event Handlers ---
void UIManager::toolDropdownEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    int sel = lv_dropdown_get_selected(ui->toolDropdown);
    ui->onToolSelect(sel);
}

void UIManager::unitToggleEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->onUnitToggle();
    lv_label_set_text(lv_obj_get_child(ui->btnUnit, 0), ui->isMetric ? "mm" : "in");
}

void UIManager::diameterToggleEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->onDiameterToggle();
    lv_label_set_text(lv_obj_get_child(ui->btnDiameter, 0), ui->isDiameterMode ? "DIA" : "RAD");
}

void UIManager::zeroXEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->onZeroX();
}

void UIManager::zeroZEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->onZeroZ();
}

void UIManager::toolEditEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    int sel = lv_dropdown_get_selected(ui->toolDropdown);

    // Popup: container for keyboard + text area
    lv_obj_t* cont = lv_obj_create(lv_scr_act());
    lv_obj_set_size(cont, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(cont, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(cont, LV_OPA_50, 0);

    // Text area
    lv_obj_t* ta = lv_textarea_create(cont);
    lv_obj_set_size(ta, 200, 40);
    lv_textarea_set_one_line(ta, true);
    lv_textarea_set_text(ta, ui->toolManager.getTool(sel).name.c_str());
    lv_obj_center(ta);

    // Keyboard
    lv_obj_t* kb = lv_keyboard_create(cont);
    lv_keyboard_set_textarea(kb, ta);
    lv_keyboard_set_mode(kb, LV_KEYBOARD_MODE_TEXT_UPPER);
    lv_obj_set_size(kb, LV_HOR_RES, 200);
    lv_obj_align(kb, LV_ALIGN_BOTTOM_MID, 0, 0);

    lv_obj_add_event_cb(kb, &UIManager::keyboardEvent, LV_EVENT_ALL, ui);
}

void UIManager::toolAddEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->onToolAdd();
}

void UIManager::toolRemoveEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    int sel = lv_dropdown_get_selected(ui->toolDropdown);
    ui->onToolRemove(sel);
}

void UIManager::keyboardEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* kb = (lv_obj_t*)lv_event_get_target(e);
    lv_obj_t* ta = lv_keyboard_get_textarea(kb);
    lv_obj_t* cont = lv_obj_get_parent(kb);
    int sel = lv_dropdown_get_selected(ui->toolDropdown);

    if (code == LV_EVENT_READY) {
        std::string newName = lv_textarea_get_text(ta);
        ui->onToolEdit(sel, newName);
        lv_obj_del_async(cont);
    } else if (code == LV_EVENT_CANCEL) {
        lv_obj_del_async(cont);
    }
}

void UIManager::showNumericInputPopup(bool isX) {
    numericInputAxis = isX ? 0 : 1;
    int containerWidth = LCD_H_RES - LCD_H_RES*4/7 - 60;
    int containerHeight = LCD_V_RES - 60;

    // Create a fullscreen transparent "block layer" to prevent inadvertent inputs
    lv_obj_t* screen_layer = lv_obj_create(lv_scr_act());
    lv_obj_set_size(screen_layer, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_opa(screen_layer, LV_OPA_TRANSP, 0); // fully transparent
    lv_obj_set_style_border_opa(screen_layer, LV_OPA_TRANSP, 0);
    lv_obj_clear_flag(screen_layer, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(screen_layer, LV_OBJ_FLAG_CLICKABLE);

    // Popup container
    lv_obj_t* win = lv_win_create(screen_layer); 
    lv_obj_set_size(win, containerWidth, containerHeight);              
    lv_obj_set_pos(win, LCD_H_RES*4/7+30, 30);              
    lv_win_add_title(win, "Set DRO Value");
    lv_obj_set_style_bg_color(win, lv_color_black(), 0);         // Black background
    lv_obj_set_style_bg_opa(win, LV_OPA_COVER, 0);               // Fully opaque
    lv_obj_set_style_border_color(win, lv_color_white(), 0);     // White border
    lv_obj_set_style_border_width(win, 3, 0);                    // 3px border
    lv_obj_set_style_radius(win, 10, 0);                         // Rounded corners

    // Text area for numeric input
    lv_obj_t* ta = lv_textarea_create(win);
    lv_obj_set_size(ta, containerWidth-6, 60);
    lv_textarea_set_one_line(ta, true);
    lv_textarea_set_text(ta, ""); // Start blank
    lv_obj_set_style_radius(ta, 0, 0);                         // Rounded corners
    lv_obj_center(ta);

    // Numeric keyboard
    lv_obj_t* kb = lv_keyboard_create(win);
    lv_keyboard_set_textarea(kb, ta);
    lv_keyboard_set_mode(kb, LV_KEYBOARD_MODE_NUMBER);
    lv_obj_set_size(kb, containerWidth-6, 300);
    lv_obj_align(kb, LV_ALIGN_BOTTOM_MID, 0, 0);

    // Pass which axis this is for as event user data (encode as int)
    lv_obj_add_event_cb(kb, &UIManager::numericKeyboardEvent, LV_EVENT_ALL, this);
}

void UIManager::numericKeyboardEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* kb = (lv_obj_t*)lv_event_get_target(e);
    lv_obj_t* ta = lv_keyboard_get_textarea(kb);
    lv_obj_t* cont = lv_obj_get_parent(lv_obj_get_parent(kb));

    if (code == LV_EVENT_READY) {
        const char* val = lv_textarea_get_text(ta);
        float fval = strtof(val, nullptr);

        // Update the tool offset
        Tool& tool = ui->toolManager.getTool(ui->currentToolIndex);
            if (ui->numericInputAxis == 0) { // X axis
            float pos_x = ui->xAxis.getPositionUm() / 1000.0f;
            float user_val = fval;
            if (!ui->isMetric) user_val = user_val / 0.0393701f;
            if (ui->isDiameterMode) user_val = user_val / 2.0f;
            tool.x_offset = pos_x - user_val;
        } else { // Z axis
            float pos_z = ui->zAxis.getPositionUm() / 1000.0f;
            float user_val = fval;
            if (!ui->isMetric) user_val = user_val / 0.0393701f;
            tool.z_offset = pos_z - user_val;
        }
        ui->toolManager.saveTools();
        ui->updateDisplay();
        lv_obj_del_async(cont);
    } else if (code == LV_EVENT_CANCEL) {
        lv_obj_del_async(cont);
    }
}

// --- Business Logic methods (all update the ViewModel and UI) ---

void UIManager::sleepBtnEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    ui->goToSleep();
}

void UIManager::goToSleep() {
    // Turn off display or backlight
    gpio_set_level(LCD_PIN_BK_LIGHT, 0);

    // Create a fullscreen transparent "wake layer"
    lv_obj_t* wake_layer = lv_obj_create(lv_scr_act());
    lv_obj_set_size(wake_layer, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_opa(wake_layer, LV_OPA_TRANSP, 0); // fully transparent
    lv_obj_set_style_border_opa(wake_layer, LV_OPA_TRANSP, 0);
    lv_obj_clear_flag(wake_layer, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(wake_layer, LV_OBJ_FLAG_CLICKABLE);

    // Attach event: any touch will wake up
    lv_obj_add_event_cb(wake_layer, &UIManager::wakeTouchEvent, LV_EVENT_CLICKED, this);
}

void UIManager::wakeTouchEvent(lv_event_t* e) {
    auto* ui = static_cast<UIManager*>(lv_event_get_user_data(e));
    gpio_set_level(LCD_PIN_BK_LIGHT, 1); // Turn ON backlight

    lv_obj_del((lv_obj_t*)lv_event_get_target(e)); // Remove wake layer
}

void UIManager::onUnitToggle() {
    isMetric = !isMetric;
    saveUnitSettings();
    updateDisplay();
}

void UIManager::onDiameterToggle() {
    isDiameterMode = !isDiameterMode;
    saveUnitSettings();
    updateDisplay();
}

void UIManager::onZeroX() {
    float pos = xAxis.getPositionUm() / 1000.0f;
    toolManager.getTool(currentToolIndex).x_offset = pos;
    toolManager.saveTools();
    updateDisplay();
}

void UIManager::onZeroZ() {
    float pos = zAxis.getPositionUm() / 1000.0f;
    toolManager.getTool(currentToolIndex).z_offset = pos;
    toolManager.saveTools();
    updateDisplay();
}

void UIManager::onToolSelect(int toolIndex) {
    loadOffsetsFromTool(toolIndex);
    updateDisplay();
}

void UIManager::onToolEdit(int toolIndex, const std::string& newName) {
    toolManager.renameTool(toolIndex, newName);
    updateToolDropdown();
    updateDisplay();
}

void UIManager::onToolAdd() {
    char name[32];
    snprintf(name, sizeof(name), "Tool %zu", toolManager.toolCount() + 1);
    toolManager.addTool(name, xAxis.getPositionUm() / 1000.0f, zAxis.getPositionUm() / 1000.0f);
    currentToolIndex = toolManager.toolCount() - 1;
    updateToolDropdown();
    lv_dropdown_set_selected(toolDropdown, currentToolIndex);
    updateDisplay();
}

void UIManager::onToolRemove(int toolIndex) {
    if (toolManager.toolCount() <= 1) return;
    toolManager.removeTool(toolIndex);
    if (currentToolIndex >= toolManager.toolCount()) currentToolIndex = toolManager.toolCount() - 1;
    updateToolDropdown();
    lv_dropdown_set_selected(toolDropdown, currentToolIndex);
    updateDisplay();
}

void UIManager::saveUnitSettings() {
    prefs.putUShort("is_metric", isMetric ? 1 : 0);
    prefs.putUShort("is_diameter", isDiameterMode ? 1 : 0);
}

void UIManager::loadUnitSettings() {
    isMetric =       prefs.getUShort("is_metric", 1) != 0;   // default to metric
    isDiameterMode = prefs.getUShort("is_diameter", 0) != 0; // default to RAD
}
