#pragma once
#include <string>
#include <vector>
#include <cstdio>
#include "tool.h"

// ---------- Axis ViewModel ----------
struct DROAxisViewModel {
    float position_um = 0.0f;        // Raw axis position in microns
    float display_value = 0.0f;      // Value after offsets/conversion, for UI
    std::string formatted_text;      // Pre-formatted display string, e.g. "12.0032"
    std::string label;               // Axis label ("X", "Z", etc.)

    DROAxisViewModel() = default;
    DROAxisViewModel(const std::string& axis_label)
        : label(axis_label) {}
};

// ---------- Tool ViewModel ----------
struct ToolViewModel {
    std::string name;
    float x_offset = 0.0f;
    float z_offset = 0.0f;
    int tool_index = 0;
    bool is_current = false;

    // Constructor for fast population
    ToolViewModel(
        const std::string& n,
        float x,
        float z,
        int idx,
        bool current)
        : name(n), x_offset(x), z_offset(z), tool_index(idx), is_current(current)
    {}

    ToolViewModel() = default;

    // Optional: Helper for UI dropdowns, etc.
    std::string displayString() const {
        char buf[64];
        snprintf(buf, sizeof(buf), "%s (%.3f, %.3f)", name.c_str(), x_offset, z_offset);
        return std::string(buf);
    }
};

// ---------- Main ViewModel ----------
struct MainDROViewModel {
    DROAxisViewModel x_axis;
    DROAxisViewModel z_axis;
    ToolViewModel current_tool;
    bool is_metric = true;
    bool is_diameter_mode = false;
    std::vector<ToolViewModel> tool_list;

    // For editing
    std::string tool_name_being_edited;

    MainDROViewModel()
        : x_axis("X"), z_axis("Z") {}
};
