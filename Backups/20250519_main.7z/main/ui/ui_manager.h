#pragma once
#include <string>
#include "tool_manager.h"
#include "dro_axis.h"
#include "preferences_wrapper.h"
#include "viewmodels.h"

extern "C" {
    #include <lvgl.h>
}

class UIManager {
public:
    UIManager(ToolManager& toolManager, DroAxis& xAxis, DroAxis& zAxis, PreferencesWrapper& prefs);

    void init();
    void updateDisplay();

    // Public for UI event logic, but not called directly from LVGL:
    void onUnitToggle();
    void onDiameterToggle();
    void onZeroX();
    void onZeroZ();
    void onToolSelect(int toolIndex);
    void onToolEdit(int toolIndex, const std::string& newName);
    void onToolAdd();
    void onToolRemove(int toolIndex);

private:
    ToolManager& toolManager;
    DroAxis& xAxis;
    DroAxis& zAxis;
    PreferencesWrapper& prefs;
    MainDROViewModel viewModel; 
    
    bool isMetric = true;
    bool isDiameterMode = false;
    int currentToolIndex = 0;
    int numericInputAxis = 0; // 0 = X, 1 = Z

    // LVGL object handles
    lv_obj_t* labelX = nullptr;
    lv_obj_t* labelZ = nullptr;
    lv_obj_t* droX = nullptr;
    lv_obj_t* droZ = nullptr;
    lv_obj_t* toolDropdown = nullptr;
    lv_obj_t* btnUnit = nullptr;
    lv_obj_t* btnDiameter = nullptr;
    lv_obj_t* btnZeroX = nullptr;
    lv_obj_t* btnZeroZ = nullptr;
    lv_obj_t* btnToolEdit = nullptr;
    lv_obj_t* btnToolAdd = nullptr;
    lv_obj_t* btnToolRemove = nullptr;
    lv_obj_t* btnScreenSleep = nullptr;

    void updateToolDropdown();
    void loadOffsetsFromTool(int index);

    float getDisplayX() const;
    float getDisplayZ() const;

    // ---- LVGL static event handlers ----
    static void toolDropdownEvent(lv_event_t* e);
    static void unitToggleEvent(lv_event_t* e);
    static void diameterToggleEvent(lv_event_t* e);
    static void zeroXEvent(lv_event_t* e);
    static void zeroZEvent(lv_event_t* e);
    static void toolEditEvent(lv_event_t* e);
    static void toolAddEvent(lv_event_t* e);
    static void toolRemoveEvent(lv_event_t* e);
    static void keyboardEvent(lv_event_t* e);
    static void droXInputEvent(lv_event_t* e);
    static void droZInputEvent(lv_event_t* e);
    void showNumericInputPopup(bool isX);
    static void numericKeyboardEvent(lv_event_t* e);
    void saveUnitSettings();
    void loadUnitSettings();
    void goToSleep();
    static void sleepBtnEvent(lv_event_t* e);
    static void wakeTouchEvent(lv_event_t* e);
};
