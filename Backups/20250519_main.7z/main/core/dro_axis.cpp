#include "dro_axis.h"
#include <driver/gpio.h>
#include <esp_attr.h>   // for IRAM_ATTR
#include "esp_log.h"

// --- Interrupt handler: dispatch to the correct axis instance ---
extern "C" void IRAM_ATTR generic_axis_isr(void* arg) {
    if (arg) {
        static_cast<DroAxis*>(arg)->handleInterrupt();
    }
}

DroAxis::DroAxis(int pinA, int pinB, int32_t step_um)
    : pinA(pinA), pinB(pinB), step_um(step_um), position_um(0), last_state(0) {}

void DroAxis::begin() {
    // Configure pins as input with pull-up
    gpio_config_t io_conf = {};
    io_conf.intr_type = GPIO_INTR_ANYEDGE;
    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pin_bit_mask = (1ULL << pinA) | (1ULL << pinB);
    
    ESP_LOGI("MYDBG", "Calling gpio_config(io_conf) in dro axis");
    esp_err_t err = gpio_config(&io_conf);
    ESP_LOGI("MYDBG", "gpio_set_level ret = %d", err);

    // Read initial state
    uint8_t sA = gpio_get_level((gpio_num_t)pinA);
    uint8_t sB = gpio_get_level((gpio_num_t)pinB);
    last_state = (sA << 1) | sB;

    // Attach interrupts (assume ISR service already installed by HAL)
    gpio_isr_handler_add((gpio_num_t)pinA, generic_axis_isr, this);
    gpio_isr_handler_add((gpio_num_t)pinB, generic_axis_isr, this);
}

void DroAxis::zero() {
    position_um.store(0, std::memory_order_relaxed);
}

void DroAxis::setPositionUm(int32_t newPos) {
    position_um.store(newPos, std::memory_order_relaxed);
}

int32_t DroAxis::getPositionUm() const {
    return position_um.load(std::memory_order_relaxed);
}

void DroAxis::handleInterrupt() {
    // Read both pins
    uint8_t sA = gpio_get_level((gpio_num_t)pinA);
    uint8_t sB = gpio_get_level((gpio_num_t)pinB);
    uint8_t state = (sA << 1) | sB;
    uint8_t prev = last_state.load(std::memory_order_relaxed);

    // Decode direction using full state machine
    static const int8_t table[4][4] = {
        { 0,  -1,  1,  0 },
        { 1,   0,  0, -1 },
        {-1,   0,  0,  1 },
        { 0,   1, -1,  0 }
    };
    int8_t dir = table[prev][state];

    if (dir != 0) {
        position_um.fetch_add(dir * step_um, std::memory_order_relaxed);
    }

    last_state.store(state, std::memory_order_relaxed);
}

void DroAxis::simulateStep(bool forward) {
    // For unit testing: increment or decrement position
    position_um.fetch_add(forward ? step_um : -step_um, std::memory_order_relaxed);
}
