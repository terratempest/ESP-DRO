#pragma once

// LVGL (adjust include path as needed for your project)
extern "C" {
    #include <lvgl.h>
    // ... and your LVGL display/touch drivers
}

// Call this during setup() to initialize the display and touch panel
void app_display_init();

// If you need to trigger display/touch polling/ticking outside of loop(), add helper(s) here
// e.g. void app_display_tick();
