#pragma once
#include <atomic>
#include <stdint.h>

extern "C" void generic_axis_isr(void* arg);

class DroAxis {
public:
    DroAxis(int pinA, int pinB, int32_t step_um = 5);
    void begin();
    void zero();
    void setPositionUm(int32_t newPos);
    int32_t getPositionUm() const;
    void simulateStep(bool forward);

    // --- THIS MUST BE PUBLIC! ---
    void handleInterrupt();

private:
    int pinA, pinB;
    int32_t step_um;
    std::atomic<int32_t> position_um;
    std::atomic<uint8_t> last_state;
};
