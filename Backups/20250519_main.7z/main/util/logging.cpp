#include "logging.h"
#include <stdarg.h>
#include <cstdio>

static const char* level_str(LogLevel level) {
    switch (level) {
        case LOG_DEBUG: return "DEBUG";
        case LOG_INFO:  return "INFO";
        case LOG_WARN:  return "WARN";
        case LOG_ERROR: return "ERROR";
        default:        return "?";
    }
}

void log_print(LogLevel level, const char* file, int line, const char* fmt, ...) {
    char buf[256];

    // Print prefix: [LEVEL] file:line
    int prefix_len = snprintf(buf, sizeof(buf), "[%s] %s:%d: ", level_str(level), file, line);

    // Format main message
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf + prefix_len, sizeof(buf) - prefix_len, fmt, args);
    va_end(args);

    // Output using ESP-IDF logging
    switch (level) {
        case LOG_DEBUG:
            ESP_LOGD("APP", "%s", buf);
            break;
        case LOG_INFO:
            ESP_LOGI("APP", "%s", buf);
            break;
        case LOG_WARN:
            ESP_LOGW("APP", "%s", buf);
            break;
        case LOG_ERROR:
            ESP_LOGE("APP", "%s", buf);
            break;
        default:
            ESP_LOGI("APP", "%s", buf);
            break;
    }
}
