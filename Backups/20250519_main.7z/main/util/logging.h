#pragma once

#include "esp_log.h"

// Severity levels (expand as needed)
enum LogLevel {
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR
};

// Set the minimum level to print (adjust as needed)
#define LOG_MIN_LEVEL LOG_DEBUG

// Main logging macro. Usage: LOG_INFO("Hello %d", 42);
#define LOG(level, fmt, ...) do { \
    if ((level) >= LOG_MIN_LEVEL) { \
        log_print(level, __FILE__, __LINE__, fmt, ##__VA_ARGS__); \
    } \
} while(0)

// Convenience macros for each level
#define LOG_DEBUG(fmt, ...) LOG(LOG_DEBUG, fmt, ##__VA_ARGS__)
#define LOG_INFO(fmt, ...)  LOG(LOG_INFO,  fmt, ##__VA_ARGS__)
#define LOG_WARN(fmt, ...)  LOG(LOG_WARN,  fmt, ##__VA_ARGS__)
#define LOG_ERROR(fmt, ...) LOG(LOG_ERROR, fmt, ##__VA_ARGS__)

// The implementation function
void log_print(LogLevel level, const char* file, int line, const char* fmt, ...);
