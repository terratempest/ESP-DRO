#pragma once
#include <cstdint>
#include "hardware_abstraction.h"
#include "dro_axis.h"

// Setup all encoder interrupts (call this during hardware init)
void setupAxisInterrupts(HardwareAbstraction& hw, DroAxis& xAxis, DroAxis& zAxis);

// If you add more axes, expand this as needed
