#include "interrupts.h"
#include "esp_attr.h"
#include "driver/gpio.h"
#include "config.h"

// ISR wrappers -- just call the object's handler
void IRAM_ATTR xAxisISR(void* ctx) {
    static_cast<DroAxis*>(ctx)->handleInterrupt();
}
void IRAM_ATTR zAxisISR(void* ctx) {
    static_cast<DroAxis*>(ctx)->handleInterrupt();
}

bool isr_service_installed = false;

void setupAxisInterrupts(HardwareAbstraction& hw, DroAxis& xAxis, DroAxis& zAxis) {
    
    // Enable GPIO ISR service if not already enabled
    if (!isr_service_installed) {
        gpio_install_isr_service(0); // 0 = default interrupt allocation flags
        isr_service_installed = true;
    }

    // Attach interrupts to the appropriate pins with the HAL
    
    // X axis
    hw.attachInterrupt(X_AXIS_PIN_A, xAxisISR, &xAxis, GPIO_INTR_ANYEDGE);
    hw.attachInterrupt(X_AXIS_PIN_B, xAxisISR, &xAxis, GPIO_INTR_ANYEDGE);

    // Z axis
    hw.attachInterrupt(Z_AXIS_PIN_A, zAxisISR, &zAxis, GPIO_INTR_ANYEDGE);
    hw.attachInterrupt(Z_AXIS_PIN_B, zAxisISR, &zAxis, GPIO_INTR_ANYEDGE);

}
