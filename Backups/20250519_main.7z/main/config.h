#pragma once

//----------------------------------------
// MACHINE/PROJECT CONFIGURATION
//----------------------------------------

// Axis/Encoder config
#define DRO_NUM_AXES    2

// Pins for DRO scales (adjust as needed)
#define X_AXIS_PIN_A    17
#define X_AXIS_PIN_B    11
#define Z_AXIS_PIN_A    12
#define Z_AXIS_PIN_B    13

// Scale parameters (microns per pulse, etc.)
#define X_AXIS_MICRONS_PER_PULSE   5.0f
#define Z_AXIS_MICRONS_PER_PULSE   5.0f

// Accuracy/Resolution (optional)
#define X_AXIS_ACCURACY_UM         5
#define Z_AXIS_ACCURACY_UM         5

// Number of tools supported (for array allocation, if needed)
#define CONFIG_MAX_TOOLS 16

// UI/TFT/LCD config (adjust for your display)
#define TFT_WIDTH   800
#define TFT_HEIGHT  480
#define LCD_H_RES TFT_WIDTH
#define LCD_V_RES TFT_HEIGHT

// Feature toggles (set to 1/0)
#define ENABLE_DIAMETER_MODE   1
#define ENABLE_METRIC_TOGGLE   1
#define ENABLE_TOOL_MANAGEMENT 1

//----------------------------------------
// PREFERENCES STORAGE
//----------------------------------------
#define NVS_NAMESPACE          "settings"
#define NVS_VERSION 1

//----------------------------------------
// LOGGING
//----------------------------------------
#define DEFAULT_LOG_LEVEL      LOG_INFO

//----------------------------------------
// DISPLAY & TOUCH
//----------------------------------------

// Pixel clock
#define LCD_PIXEL_CLOCK_HZ  12500000U

// Data lines
#define DATA_GPIOS      {15, 7, 6, 5, 4, 9, 46, 3, 8, 16, 1, 14, 21, 47, 48, 45}

// Board pin mapping
#define LCD_PIN_HSYNC    GPIO_NUM_39
#define LCD_PIN_VSYNC    GPIO_NUM_40
#define LCD_PIN_DE       GPIO_NUM_41
#define LCD_PIN_PCLK     GPIO_NUM_42
#define LCD_PIN_BK_LIGHT GPIO_NUM_2

#define TOUCH_RST        GPIO_NUM_38
#define TOUCH_INT        GPIO_NUM_18
#define TOUCH_I2C_SDA    GPIO_NUM_19
#define TOUCH_I2C_SCL    GPIO_NUM_20
#define TOUCH_I2C_NUM    I2C_NUM_0
#define TOUCH_I2C_ADDR   0x5D  // GT911 Address for your hardware